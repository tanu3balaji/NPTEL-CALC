"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export function NptelCalculator() {
  const [courseWeeks, setCourseWeeks] = useState<"4" | "8" | "12">("4")
  const [weeklyScores, setWeeklyScores] = useState<number[]>([])
  const [assignmentScore, setAssignmentScore] = useState(0)

  // Initialize weekly scores based on course duration
  useEffect(() => {
    const weeks = Number.parseInt(courseWeeks)
    setWeeklyScores(Array(weeks).fill(0))
  }, [courseWeeks])

  // Update a specific week's score
  const updateWeekScore = (index: number, value: string) => {
    const newScore = Math.min(Math.max(Number.parseInt(value) || 0, 0), 100)
    const newScores = [...weeklyScores]
    newScores[index] = newScore
    setWeeklyScores(newScores)
  }

  // Calculate assignment score based on course duration and best scores
  useEffect(() => {
    const weeks = Number.parseInt(courseWeeks)
    let bestWeeks: number

    if (weeks === 4) bestWeeks = 3
    else if (weeks === 8) bestWeeks = 6
    else bestWeeks = 8

    // Sort scores in descending order and take the best ones
    const sortedScores = [...weeklyScores].sort((a, b) => b - a)
    const bestScores = sortedScores.slice(0, bestWeeks)

    // Calculate average of best scores
    const average = bestScores.reduce((sum, score) => sum + score, 0) / bestWeeks

    // Assignment is 25% of the average
    setAssignmentScore(average * 0.25)
  }, [weeklyScores, courseWeeks])

  // Calculate required written exam scores for different certification levels
  function calculateRequiredExamScore(targetTotal: number) {
    // Written exam is out of 100 but contributes 75% to final grade
    // So we need to find what score out of 100 will give us the required contribution
    const requiredContribution = targetTotal - assignmentScore
    const rawScore = Math.max(Math.ceil(requiredContribution / 0.75), 0)
    const contribution = (rawScore * 0.75).toFixed(2)
    return { rawScore, contribution }
  }

  // Determine current certification status
  const getCertificationStatus = () => {
    if (assignmentScore < 10) return "Fail (Assignment score below 10)"

    const totalPossible = assignmentScore + 75 // Max possible if they get 100 on exam

    if (totalPossible >= 90) return "Gold possible"
    if (totalPossible >= 60) return "Elite possible"
    if (totalPossible >= 40) return "Successful completion possible"
    return "Cannot pass even with perfect exam score"
  }

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>NPTEL Assignment Calculator</CardTitle>
        <CardDescription>Calculate your assignment score and required exam score for certification</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={courseWeeks} onValueChange={(value) => setCourseWeeks(value as "4" | "8" | "12")}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="4">4 Weeks</TabsTrigger>
            <TabsTrigger value="8">8 Weeks</TabsTrigger>
            <TabsTrigger value="12">12 Weeks</TabsTrigger>
          </TabsList>

          <TabsContent value="4" className="space-y-4">
            <p className="text-sm text-muted-foreground mb-4">
              For 4-week courses, assignment score is 25% of the average of your best 3 weeks.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Array.from({ length: 4 }).map((_, index) => (
                <div key={index} className="space-y-2">
                  <Label htmlFor={`week-${index + 1}`}>Week {index + 1}</Label>
                  <Input
                    id={`week-${index + 1}`}
                    type="number"
                    min="0"
                    max="100"
                    value={weeklyScores[index] || 0}
                    onChange={(e) => updateWeekScore(index, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="8" className="space-y-4">
            <p className="text-sm text-muted-foreground mb-4">
              For 8-week courses, assignment score is 25% of the average of your best 6 weeks.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, index) => (
                <div key={index} className="space-y-2">
                  <Label htmlFor={`week-${index + 1}`}>Week {index + 1}</Label>
                  <Input
                    id={`week-${index + 1}`}
                    type="number"
                    min="0"
                    max="100"
                    value={weeklyScores[index] || 0}
                    onChange={(e) => updateWeekScore(index, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="12" className="space-y-4">
            <p className="text-sm text-muted-foreground mb-4">
              For 12-week courses, assignment score is 25% of the average of your best 8 weeks.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Array.from({ length: 12 }).map((_, index) => (
                <div key={index} className="space-y-2">
                  <Label htmlFor={`week-${index + 1}`}>Week {index + 1}</Label>
                  <Input
                    id={`week-${index + 1}`}
                    type="number"
                    min="0"
                    max="100"
                    value={weeklyScores[index] || 0}
                    onChange={(e) => updateWeekScore(index, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-8 space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Your Assignment Score (25%)</h3>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold">{assignmentScore.toFixed(2)}</span>
              <span className="text-sm text-muted-foreground">out of 25</span>
            </div>
            <Progress value={(assignmentScore / 25) * 100} className="h-2" />
          </div>

          <Alert>
            <InfoIcon className="h-4 w-4" />
            <AlertTitle>Current Status</AlertTitle>
            <AlertDescription>{getCertificationStatus()}</AlertDescription>
          </Alert>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Required Exam Score</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="py-4">
                  <CardTitle className="text-md">Gold Certificate</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{calculateRequiredExamScore(90).rawScore}</p>
                  <p className="text-sm text-muted-foreground">out of 100</p>
                  <p className="text-sm mt-1">
                    Contributes <span className="font-semibold">{calculateRequiredExamScore(90).contribution}</span>/75
                    to final grade
                  </p>
                  {calculateRequiredExamScore(90).rawScore > 100 && (
                    <p className="text-sm text-red-500 mt-2">Not possible</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="py-4">
                  <CardTitle className="text-md">Elite Certificate</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{calculateRequiredExamScore(60).rawScore}</p>
                  <p className="text-sm text-muted-foreground">out of 100</p>
                  <p className="text-sm mt-1">
                    Contributes <span className="font-semibold">{calculateRequiredExamScore(60).contribution}</span>/75
                    to final grade
                  </p>
                  {calculateRequiredExamScore(60).rawScore > 100 && (
                    <p className="text-sm text-red-500 mt-2">Not possible</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="py-4">
                  <CardTitle className="text-md">Successful Completion</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{calculateRequiredExamScore(40).rawScore}</p>
                  <p className="text-sm text-muted-foreground">out of 100</p>
                  <p className="text-sm mt-1">
                    Contributes <span className="font-semibold">{calculateRequiredExamScore(40).contribution}</span>/75
                    to final grade
                  </p>
                  {calculateRequiredExamScore(40).rawScore > 100 && (
                    <p className="text-sm text-red-500 mt-2">Not possible</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
